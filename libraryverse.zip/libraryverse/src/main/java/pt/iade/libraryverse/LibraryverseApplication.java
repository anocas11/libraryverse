package pt.iade.libraryverse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryverseApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryverseApplication.class, args);
	}

}
