package pt.iade.libraryverse.models;

public class Author{

}